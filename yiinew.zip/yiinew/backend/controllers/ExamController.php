<?php 
	namespace backend\controllers;

	use yii;
	use yii\web\Controller;
	use common\libs\curl;
	use common\libs\PHPExcel;
	/**
	 * 
	 */
	header('content-type:text/html;charset=utf8');
	class ExamController extends Controller
	{
		
		public $enableCsrfValidation = false;
		//试题添加
		public function actionAdd(){

			if (yii::$app->request->isPost) {
				

				$dir = '/phpstudy/www/Wechat/yiinew/backend/uploads/excel.xls';
				$res = move_uploaded_file($_FILES['file']['tmp_name'], $dir);
				if ($res) {
					$url = "http://47.93.199.34/Wechat/yiinew/api/web/index.php?r=exam/index";
					$params = yii::$app->request->post();
					$file['file'] = $dir;
					$reg = curl::_post($url , $params , $file);
					if ($reg) {
						 $this->redirect('http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/show');
						// echo $reg;
					}
				}
				
			}else{
				return $this->render('add');
			}
			
		}
	}
 ?>