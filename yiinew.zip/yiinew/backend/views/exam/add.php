<ul class="breadcrumb">
<li><a href="#">试题管理</a></li>
<li class="active">试题导入</li>
</ul>
<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/show'" class="btn btn-primary" data-toggle="button">试题列表</button>
<form role="form" method="post" action="index.php?r=exam/add" enctype="multipart/form-data">
	
  <!-- <div class="form-group">
    <label for="name">名称</label>
    <input type="text" class="form-control" id="name" name="title" placeholder="请输入名称">
  </div> -->
   <select name="month" class="form-control" style="width: 250px;">
    <option value="">请选择月份</option>}
    option
        <?php foreach (yii::$app->params['month'] as $key => $val) {?>
        <option value="<?=$key?>"><?=$val?></option>
      <?php }?>
  </select>
 
<br>
 <select name="unit" class="form-control" style="width: 250px;">
    <option value="">请选择单元</option>}
    option
        <?php foreach (yii::$app->params['unit'] as $key => $val) {?>
        <option value="<?=$key?>"><?=$val?></option>
      <?php }?>
  </select>
 

  <div class="form-group">
    <label for="inputfile">文件输入</label>
    <input type="file" id="inputfile" name="file">
  </div>
  <button type="submit" class="btn btn-default">提交</button>
</form>