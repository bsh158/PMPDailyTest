<?php 
	namespace frontend\controllers;

	use yii;
	use yii\web\Controller;
	use common\libs\curl;
	/**
	 * 
	 */
	header('content-type:text/html;charset=utf8');
	class ExamController extends Controller
	{

		//试题列表
		public function actionShow(){


			//请求接口查询数据
			$url = "http://47.93.199.34/Wechat/yiinew/api/web/index.php?r=exam/show";
			$data = curl::_get($url);
			$data = json_decode($data, true);
			return $this->render('show',['data'=>$data['content'],'page'=>$data['page']]);
		}

		//试题展示
		public function actionShowpro(){
			$get = yii::$app->request->get('unit');

			//查询试题和答案信息
			$data = yii::$app->db->createCommand("select * from test join answer on test.tid =answer.tid where unit = '".$get."'")->queryAll();

			//处理答案数据
			foreach ($data as $key => $val) {

				if (!isset($arr[$val['tid']])) {
					$arr[$val['tid']]=$val;
				}
				 unset($arr[$val['tid']]['aid'],$arr[$val['tid']]['option'],$arr[$val['tid']]['is_yes']);
				$child = array(
					'aid'	 => $val['aid'],
					'option' => $val['option'],
					'is_yes' => $val['is_yes'],
				);
				$arr[$val['tid']]['options'][] = $child;
			}
			
			return $this->render('showpro',['title'=>$get,'arr'=>$arr]);
		}

		//试题练习
		public function actionExam(){
			return $this->render('exam');
		}
	}
 ?>