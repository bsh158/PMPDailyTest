<ul class="breadcrumb">
<li><a href="#">试题管理</a></li>
<li class="active">试题列表</li>
</ul>
<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/exam'" class="btn btn-primary" data-toggle="button">试题练习</button>

<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/backend/web/index.php?r=exam/add'" class="btn btn-primary" data-toggle="button">试题添加</button>
<table class="table table-condensed">
	<thead>
	<tr>
		<th>月份</th>
		<th>单元</th>
		<th>出题人</th>
		<th>添加时间</th>
		<th>操作</th>
	</tr>
	</thead>
<tbody>
	<?php
		foreach ($data as $key => $val) {
		
	?>
	<tr>
		<td><?=$val['month']?></td>
		<td><?=$val['unit']?></td>
		<td><?=$val['adduser']?></td>
		<td><?php echo date('Y-m-d H:i:s',$val['time']) ?></td>
		<td>
			<button type="button"  onclick="javascript:window.location='index.php?r=exam/showpro&unit=<?=$val['unit']?>'" class="btn btn-primary" data-toggle="button">查看</button>
		</td>
	</tr>
<?php }?>
</tbody>
</table>
<!-- <div id="page">
	<?=$page?>
</div> -->