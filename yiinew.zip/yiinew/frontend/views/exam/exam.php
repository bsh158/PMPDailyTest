
<?php foreach (yii::$app->params['month'] as $key => $value) {
?>
	12345
<?php }?>