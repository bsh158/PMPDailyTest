<ul class="breadcrumb">
<li><a href="#">试题管理</a></li>
<li><a href="http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/show">试题列表</a></li>
<li class="active"><?=$title?></li>
</ul>

<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/exam'" class="btn btn-primary" data-toggle="button">试题练习</button>

<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/frontend/web/index.php?r=exam/show'" class="btn btn-primary" data-toggle="button">试题列表</button>

<button type="button" style="float: right;" onclick="javascript:window.location='http://47.93.199.34/Wechat/yiinew/backend/web/index.php?r=exam/add'" class="btn btn-primary" data-toggle="button">试题添加</button>



<table class="table table-bordered">
	<?php
		$i = 1;
		foreach ($arr as $key => $val) {
	?>
	<thead>
		<tr>
			<th style="background-color: lightgray ;"><?=$i?>.&nbsp;<?=$val['title']?></th>
		</tr>
	</thead>
<tbody>
	<?php 
		foreach ($val['options'] as $k => $v) {
	?>
	<tr>
		<td>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$v['option']?>
			<?php if ($v['is_yes'] == 1){?>
			<span style="color: green;float: right;margin-right: 200px;">对</span>
			<?php }?>
		</td>
		
	</tr>
</tbody>
<?php 
	}
$i++;
}
?>
</table>