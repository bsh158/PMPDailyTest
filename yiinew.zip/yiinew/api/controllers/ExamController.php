<?php 
    namespace api\controllers;

    use yii;
    use yii\web\Controller;
    use common\libs\curl;
    use common\libs\PHPExcel;
    /**
     * 
     */
    header('content-type:text/html;charset=utf8');
    class ExamController extends Controller
    {

        public $enableCsrfValidation = false;
        //考题答案添加入库
        public function actionIndex(){
             $dir = '/phpstudy/www/Wechat/yiinew/api/uploads/excel.xls';
             move_uploaded_file($_FILES['file']['tmp_name'] , $dir);

             $params = yii::$app->request->post();

            require(__DIR__ . '/../../common/libs/PHPExcel.php');
            $excel = new \PHPExcel();
            //找文件
            $object = \PHPExcel_IOFactory::load($dir);
            //找活动表
            $sheet = $object->getActiveSheet()->toArray(null,true,true,true);
            unset($sheet[1]);
            $type = array_flip(yii::$app->params['type']);
            $score = yii::$app->params['score'];

            $time = time();
            foreach ($sheet as $key => $val) {
                 $arr = array(
                    'title'  => $val['C'],
                    'month'  => $params['month'],
                    'unit'   => $params['unit'],
                    'type'   => $type[$val['B']],
                    'score'  => $score[$type[$val['B']]],
                    'adduser' => $val['L'],
                    'time'   => $time
                    );

                 //写入试题
                 $t =yii::$app->db->createCommand()->insert('test',$arr)->execute();
                 $tid = yii::$app->db->getLastInsertID();
                
                //题号
            $a_num = array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

                $yesinfo = str_split($val['J'],1);

                //试题答案
                for ($i = 'D'; $i <= 'I' ; $i++) { 

                    if (empty($val[$i])) continue;

                    $is_yes = in_array($a_num[$i], $yesinfo) ? 1 : 0;
                    $answer = array(
                            'tid' => $tid,
                            'option' => $val[$i],
                            'is_yes' => $is_yes
                    );
                     $t_n =yii::$app->db->createCommand()->insert('answer',$answer)->execute();
                     
                }
            }
            if ($t && $t_n) {
                echo "OK";exit;
            }
        }

        //试题列表
        public function actionShow(){

            //接收客户端发送过来的参数
            $p = yii::$app->request->get('p',1);

            $psize = yii::$app->request->get('psize',7);

            //查询分页数用的数据总条数  $con["count(*)"]
            $con = yii::$app->db->createCommand('select count(*) from test')->queryOne();

            //计算页面偏移量
            $limit = ($p-1)*$psize;

               $data['page'] = $this->page($con["count(*)"],$p);

            $sql = "select DISTINCT unit,month,adduser,time from test";
            $data['content'] = yii::$app->db->createCommand($sql)->queryAll();
            $data = json_encode($data);

            echo $data;
        }

        //分页的页码
        public function page($count,$p){

            //页码的开始
            $start = $p-3;
            if ($start<1) $start = 1;
            //页码的结束
            $end = $start+6;
            if ($end > $count) $end=$count;
            $str = '<ul class="pagination">';
            for ($i=$start; $i < $end; $i++) { 
                if ($p == $i) {
                    $str .= '<li class="active"><a href="javascript:void(0)" p='.$i.'>'.$i.'</a></li>';
                }else{
                    $str .= '<li><a href="javascript:void(0)" p='.$i.'>'.$i.'</a></li>';
                }
            }
            $str .= '</ul>';

            return $str;
        }
    }
 ?>